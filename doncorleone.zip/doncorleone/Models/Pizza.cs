using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace tppizzeria.Models
{
    public class Pizza{
        private int _IdPizza;
        private string _Nombre;
        private int _Precio;
        private string _Tamano;
        private string _UrlFoto;
        private List<string> _ListaIngredientes = new List<string>();

        public int IdPizza{get{return _IdPizza;}}
        public string Nombre{get{return _Nombre;}}
        public int Precio{get{return _Precio;}}
        public string Tamano {get{return _Tamano;}}
        public string UrlFoto {get{return _UrlFoto;}}
        public List<string> ListaIngredientes{get{return _ListaIngredientes;}}  

        public Pizza(string nombre, string url, string tamano, int precio){
           _IdPizza= Pizzeria.UltimoIdPizza();
           _Nombre=nombre;
           _UrlFoto=url;
           _Tamano=tamano;
           _Precio=precio;
        }

        public List<string> DevolverListaIngredientes(){
            return _ListaIngredientes;
        }

        public void AgregarIngredientes(List<string> Lista){
            _ListaIngredientes = Lista;
        }
    }
}