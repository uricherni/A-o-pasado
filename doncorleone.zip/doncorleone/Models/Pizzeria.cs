using System;
using System.Collections.Generic;

namespace tppizzeria.Models
{
    public static class Pizzeria{
        private static int _IdP =0;
        private static int _IDI =0;
        private static List<Ingrediente> _ListaIngredientes= new List<Ingrediente>();
        private static List<Pizza> _ListaPizzas = new List<Pizza>();

        public static List<Ingrediente> ListarIngredientes(){
            _ListaIngredientes.Clear();
            _ListaIngredientes.Add(new Ingrediente("Muzzarella", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Parmesano", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Provolone", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Jamon", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Morron", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Huevo", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Cebolla", "muzza.png"));
            _ListaIngredientes.Add(new Ingrediente("Longaniza", "muzza.png"));

            return _ListaIngredientes;
        }

        public static int UltimoIdPizza()
        {
            _IdP++;
            return _IdP;
        }

        public static int UltimoIdIngrediente(){
            _IDI++;
            return _IDI;
        }

        public static List<Pizza> ListarPizzas(){
            return _ListaPizzas;
        }
        public static void AgregarPizza(Pizza UnaPizza){
            _ListaPizzas.Add(UnaPizza);
        }
        public static void EliminarPizza(Pizza UnaPizza){
            _ListaPizzas.Remove(UnaPizza);   
        }
    }
    
}