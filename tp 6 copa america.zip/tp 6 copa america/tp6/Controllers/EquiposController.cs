using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using tp6.Models;

namespace tp6.Controllers
{
    public class EquiposController : Controller
    {
        public IActionResult VerEquipos()
        {  
            string[] Equipos = new string [10]{"Brasil","Argentina","Colombia","Chile","Ecuador","Peru","Paraguay","Venezuela","Bolivia","Uruguay"};
            
            ViewBag.Equipos = Equipos;
            return View();
        }
        public IActionResult VerJugadoresEquipo(string Equipo)
        {
            string[] Paraguay = new string [11]{"Antony Silva","Alberto Espínola","Gustavo Gómez Portillo","Junior Alonso","Santiago Arzamendia","Andrés Cubas","Robert Piris Da Motta","Ángel Romero Villamayor","Alejandro Romero Gamarra","Miguel Almirón","Gabriel Ávalos"};
            string[] EquiposParaguay= new string [11]{"Club Puebla","Cerro Porteño","Palmeiras","Club Atlético Mineiro","Club Cerro Porteño","Nîmes Olympique Football Club","Flamengo","Club Atlético San Lorenzo de Almagro","Al-Taawoun FC","Newcastle United","Argentinos Juniors"};
            string[] Colombia = new string [11]{"David Ospina","William Tesillo","Davinson Sánchez","Yerry Mina","Stefan Medina","Sebastián Pérez","Wilmar Barrios","Duván Zapata","Edwin Cardona","Juan Guillermo Cuadrado","Miguel Borja"};
            string[] EquiposColombia= new string [11]{"Società Sportiva Calcio Napoli","Club León"," Tottenham Hotspur Football Club","Everton Football Club","C.F. Monterrey","Boavista Futebol Clube","Zenit de San Petersburgo"," Atalanta Bergamasca Calcio","Club Atlético Boca Juniors","Juventus de Turín","Junior de Barranquilla"};
            string[] Venezuela = new string [11]{"Wuilker Faríñez","Alexander González","Francisco La Mantía","Luis Martinez","Luis Mago","Yohan Cumana","José Andrés Martínez","Júnior Moreno","Bernaldo Manzano","Cristian Cásseres Jr.","Fernando Aristeguieta"};
            string[] EquiposVenezuela = new string [11]{" Racing Club de Lens","Málaga Club de Fútbol","Deportivo La Guaira"," Deportivo La Guaira","Universidad de Chile","Deportivo La Guaira","Philadelphia Union","D.C. United","Club Deportivo Lara","New York Red Bulls","Mazatlán Fútbol Club"};
            string[] Argentina = new string [11]{"Emiliano Martinez","Nicolas Tagliafico","Nicolas Otamendi","Cristian Romero","Nahuel Molina","Leandro Paredes","Giovanni Lo Celso","Rodrigo De Paul","Nicolas Gonzales","Lautaro Martinez","Lionel Messi"};
            string[] EquiposArgentina = new string [11]{"Aston Villa","Ajax","Benfica","Atalanta","Udinese","PSG","Tottenham","Udinese","Stuttgart","Inter","Barcelona"};
            string[] Uruguay = new string [11]{"Fernando Muslera","Matias Viña","Diego Godin","Jose Maria Gimenez","Giovvani Gonzalez","Matias Vecino","Nicolas De La Cruz","Federico Valverde","Giorgian De Arrascaeta","Edinson Cavani","Luis Suarez"};
            string[] EquiposUruguay = new string [11]{"Galatasaray","Palmeiras","Cagliari","Atletico Madrid","Peñarol","Inter","River","Real Madrid","Flamengo","Manchester United","Atletico Madrid"};
            string[] Chile = new string [11]{"Claudio Bravo","Guillermo Maripan","Gary Medel","Francisco Sierralta","Eugenio Mena","Charles Aranguiz","Erick Pulgar","Mauricio Isla","Arturo Vidal","Eduardo Vargas","Alexis Sanchez"};
            string[] EquiposChile = new string [11]{"Real Betis","Monaco","Bolonia","Watford","Racing","Bayer Leverkusen","Fiorentina","Flamengo","Inter","Atletico Mineiro","Inter"};
            string[] Brasil = new string [11]{"Alisson Becker","Renan Lodi","Marquinhos","Eder Militao","Danilo da Silva","Fred","Casemiro","Lucas Paqueta","Gabriel Jesus","Richarlison","Neymar Jr"};
            string[] EquiposBrasil = new string [11]{"Liverpool","Atletico Madrid","PSG","Real Madrid","Juventus","Manchster United","Real Madrid","Flamengo","Manchester City","Everton","PSG"};
            string[] Peru = new string [11]{"Pedro Gallese","Marcos Lopez","Luis Abram","Christian Ramos","Angel Corzo","Yoshimar Yotun","Reanto Tapia","Christian Cueva","Sergio Flores","Andre Carrillo","Gianluca Lapadula"};
            string[] EquiposPeru = new string [11]{"Orlando City","Earthquakes","Velez Sarfield","Universidad Cesar Vallejo","Universitario de Deportes","Cruz Azul","Celta de Vigo","Al-Fateh","Emmen","Al Hilal","Benevento"};
            string[] Ecuador = new string [11] {"Alexander Domínguez","Xavier Arreaga","Robert Arboleda","Angelo Preciado","Pervis Estupiñán","Ayrton Preciado","Carlos Gruezo","Jhegson Méndez","Alan Franco Palma","Enner Valencia","Ángel Mena"};
            string[] EquiposEcuador = new string [11] {"Vélez Sarsfield","Seattle Sounders FC","São Paulo","K.R.C. Genk","Villarreal","Club Santos Laguna","FC Augsburgo","Orlando City SC","Atlético Mineiro","Fenerbahçe S.K.","León"};
            string[] Bolivia = new string [11] {"Carlos Lampe","Diego Bejarano","Luis Haquín","Jairo Quinteros","Enrique Flores","Leonel Justiniano","Henry Vaca","Erwin Saavedra","Juan Carlos Arce","Rodrigo Ramallo","Marcelo Martins Moreno"};
            string[] EquiposBolivia = new string [11] {"Always Ready","Bolívar","Deportes Melipilla","Bolívar","Always Ready","Bolívar","Oriente Petrolero","Bolívar","Always Ready","Always Ready","Cruzeiro"};

            if (Equipo=="Bolivia"){

                ViewBag.Equipo = Bolivia;
                ViewBag.EquiposJugadores = EquiposBolivia;
            }
            if (Equipo=="Paraguay"){

                ViewBag.Equipo = Paraguay;
                ViewBag.EquiposJugadores = EquiposParaguay;
            }
            if (Equipo=="Ecuador"){

                ViewBag.Equipo = Ecuador;
                ViewBag.EquiposJugadores = EquiposEcuador;
            }
            if (Equipo=="Peru"){

                ViewBag.Equipo = Peru;
                ViewBag.EquiposJugadores = EquiposPeru;
            }
            if (Equipo=="Brasil"){

                ViewBag.Equipo = Brasil;
                ViewBag.EquiposJugadores = EquiposBrasil;
            }
            if (Equipo=="Chile"){

                ViewBag.Equipo = Chile;
                ViewBag.EquiposJugadores = EquiposChile;
            }
            if (Equipo=="Uruguay"){

                ViewBag.Equipo = Uruguay;
                ViewBag.EquiposJugadores = EquiposUruguay;
            }
            if (Equipo=="Argentina"){

                ViewBag.Equipo = Argentina;
                ViewBag.EquiposJugadores = EquiposArgentina;
            }
            if (Equipo=="Venezuela"){

                ViewBag.Equipo = Venezuela;
                ViewBag.EquiposJugadores = EquiposVenezuela;
            }
            if (Equipo=="Colombia"){

                ViewBag.Equipo = Colombia;
                ViewBag.EquiposJugadores = EquiposColombia;
            }

            return View();
        }
    }
}