using System;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;

namespace TP11.Models{
    public static class BD{
        //private static string _connectionString=@"server=A-CFU-04; DataBase=BDWebCursos;Trusted_Connection=true;";
        private static string _connectionString = @"Data Source=DESKTOP-43PO4QG\SQLEXPRESS01;Initial Catalog=BDWebCursos;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public static IEnumerable <Curso> ListarCursos(int IdRecibida){
            IEnumerable<Curso> CursoBuscado =null;
             string sql= "select * from Cursos where IdEspecialidad=@IdBuscado";
             using(SqlConnection db = new SqlConnection(_connectionString))
            {
                CursoBuscado = db.Query<Curso>(sql, new{ IdBuscado = IdRecibida });    
            }
            return CursoBuscado;
        }
        public static Especiadad ConsultaEspecialidad(int IdEspecialidadRecibida)
        {
            Especiadad EspecialidadBuscada = null;
            string sql = "select * from Especialidades where IdEspecialidad = @IdEspBuscada";
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                EspecialidadBuscada = db.QueryFirstOrDefault<Especiadad>(sql, new { IdEspBuscada = IdEspecialidadRecibida });
            }
            return EspecialidadBuscada;
        }
        public static Curso ConsultaCurso(int IdCursoRecibido)
        {
            Curso CursoBuscado = null;
            string sql = "select * from Cursos where IdCurso=@IdCursobuscado";
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                CursoBuscado = db.QueryFirstOrDefault<Curso>(sql, new { IdCursoBuscado = IdCursoRecibido });
            }
            return CursoBuscado;
        }
        public static bool CalificarCurso(int IdCursoRecibido, bool Calificacion)
        {
            int registrosCambiados = 0; 
            string sql;
            if (Calificacion == true)
            { 
                sql = "UPDATE Cursos SET MeGusta = MeGusta + 1 WHERE IdCurso = @IdCursobuscado";
            }
            else
            {
                sql = "UPDATE Cursos SET NoMeGusta = NoMeGusta + 1 WHERE IdCurso = @IdCursobuscado";
            }
            using (SqlConnection bd = new SqlConnection(_connectionString))
            {
                registrosCambiados = bd.Execute(sql, new { IdCursoBuscado = IdCursoRecibido });
            }
            return (registrosCambiados != 0);
        }
        public static bool AgregarCurso(Curso curso)
        {
            int registrosCambiados = 0;
            string sql = "INSERT into Cursos (Nombre, IdEspecialidad, Descripcion, Imagen, UrlCurso, Megusta, NoMeGusta)" +
                " values(@Nombre, @IdEspecialidad, @Descripcion, @Imagen, @UrlCurso, 0, 0)";
            using (SqlConnection bd = new SqlConnection(_connectionString))
            {
                registrosCambiados = bd.Execute(sql, curso);
            }
            return (registrosCambiados != 0);
        }
        public static IEnumerable<Especiadad> ListarEspecialidades()
        {
            IEnumerable<Especiadad> especialidades = null;
            string sql = "select * from Especialidades";
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                especialidades = db.Query<Especiadad>(sql);
            }
            return especialidades;
        }
        public static bool EliminarCurso(int IdCursoRecibido)
        {
            int registrosCambiados = 0;
            string sql = "delete from Cursos WHERE IdCurso = @IdCursobuscado";
            using (SqlConnection bd = new SqlConnection(_connectionString))
            {
                registrosCambiados = bd.Execute(sql, new { IdCursoBuscado = IdCursoRecibido });
            }
            return (registrosCambiados != 0);
        }
    }
}  
