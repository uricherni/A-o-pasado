using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace TP11.Models{

 public class Especiadad{

       private int _IdEspecialidad;
       private string _Nombre;
       private string _Materia;

        public int IdEspecialidad { get => _IdEspecialidad; set => _IdEspecialidad = value; }
        public string Nombre { get => _Nombre; set => _Nombre = value; }
        public string Materia { get => _Materia; set => _Materia = value; }
    }
}