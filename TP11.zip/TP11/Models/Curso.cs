using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TP11.Models{

 public class Curso{
       private int _IdCurso;
       private string _Nombre;
       private int _IdEspecialidad;
       private string _Descripcion;
       private string _Imagen;
       private string _UrlCurso;
       private string _MeGusta;
       private string _NoMeGusta;

        public int IdCurso { get => _IdCurso; set => _IdCurso = value; }
        public string Nombre { get => _Nombre; set => _Nombre = value; }
        public int IdEspecialidad { get => _IdEspecialidad; set => _IdEspecialidad = value; }
        public string Descripcion { get => _Descripcion; set => _Descripcion = value; }
        public string Imagen { get => _Imagen; set => _Imagen = value; }
        public string UrlCurso { get => _UrlCurso; set => _UrlCurso = value; }
        public string MeGusta { get => _MeGusta; set => _MeGusta = value; }
        public string NoMeGusta { get => _NoMeGusta; set => _NoMeGusta = value; }
    }
}