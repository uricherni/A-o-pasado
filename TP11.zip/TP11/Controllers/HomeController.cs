﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TP11.Models;

namespace TP11.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {

            return View();
        }
        
        [HttpGet]
        public IActionResult MostrarCursoxEspecialidad(int idespecialidad)
        {
            List <Curso> cursobuscado = BD.ListarCursos(idespecialidad).ToList();
            if ((cursobuscado == null) || (cursobuscado.Count < 1))
            {
                ViewBag.Error = 1;
                return View("Index");
            }
            else
            {
                ViewBag.Curso = cursobuscado;
                ViewBag.Especialidad = BD.ConsultaEspecialidad(Convert.ToInt32(cursobuscado[0].IdEspecialidad));
                return View("Index");
            }
        }
        
        [HttpGet]
        public IActionResult VerCurso(int idcurso)
        {
            //Curso cursobuscado = (Curso)BD.ConsultaCurso(idcurso);
            Curso cursobuscado = BD.ConsultaCurso(idcurso);
            if (cursobuscado == null)
            {
                ViewBag.Error = 1;
                return View("Index");
            }
            else
            {
                ViewBag.Curso = cursobuscado;
                return View("DetalleCurso");
            }
        }
        
        [HttpGet]
        public IActionResult Calificar(int idcurso, bool megusta, int idespecialidad)
        {
            Curso cursobuscado = BD.ConsultaCurso(idcurso);
            if (cursobuscado != null)
            {
                ViewBag.Calificado = BD.CalificarCurso(idcurso, megusta);
                //return View("Index");
                return RedirectToAction("MostrarCursoxEspecialidad", "Home", new { @idespecialidad = idespecialidad });
            }
            else
            {
                ViewBag.Error = 1;
                return View("Index");
            }
        }
        
        public IActionResult AgregarCurso()
        {
            List<Especiadad> especiadadListado = BD.ListarEspecialidades().ToList();
            if (especiadadListado == null)
            {
                ViewBag.Error = 1;
                return View("Index");
            }
            else
            {
                ViewBag.Especialidad = especiadadListado;
                return View("AgregarCurso");
            }
        }
        
        [HttpPost]
        public IActionResult GuardarCurso(string nombre, int especialidad, string descripcion, string imagen, string url)
        {
            Curso guardarCurso = new Curso();
            guardarCurso.Nombre = nombre;
            guardarCurso.Descripcion = descripcion;
            guardarCurso.Imagen = imagen;
            guardarCurso.UrlCurso = url;
            guardarCurso.IdEspecialidad = especialidad;
            
            if(BD.AgregarCurso(guardarCurso)==true)
            {
                ViewBag.Guardado = true;
                return View("Index");
            }
            else
            {
                ViewBag.Error = 1;
                return View("Index");
            }
        }
       
        }
    }
